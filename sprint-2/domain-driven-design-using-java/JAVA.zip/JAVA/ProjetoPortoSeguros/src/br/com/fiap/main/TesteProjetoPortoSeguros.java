package br.com.fiap.main;

import javax.swing.JOptionPane;

import br.com.fiap.beans.Agenda;
import br.com.fiap.beans.Carro;
import br.com.fiap.beans.Cliente;
import br.com.fiap.beans.Contato;
import br.com.fiap.beans.Endereco;
import br.com.fiap.beans.Moto;
import br.com.fiap.beans.Oficina;
import br.com.fiap.beans.Orcamento;
import br.com.fiap.beans.Pagamento;
import br.com.fiap.beans.Veiculo;

public class TesteProjetoPortoSeguros {

	public static void main(String[] args) {
		
		//ENTRADAS

		// int codigo, String nome, String dataNascimento, String profissao, String cpf,String observacao
		Cliente objCliente = new Cliente(Integer.parseInt(JOptionPane.showInputDialog("Informe o código do Cliente")),
				JOptionPane.showInputDialog("Informe o nome do cliente"),
				JOptionPane.showInputDialog("Informe a data de nascimento do cliente"),
				JOptionPane.showInputDialog("Informe a profissão o cliente"),
				JOptionPane.showInputDialog("Informe o CPF o cliente"));

		// int codigo, String tipo, String montadora, String motor, String anoFabricacao, String placa,String dono
		Veiculo objVeiculo = new Veiculo(Integer.parseInt(JOptionPane.showInputDialog("Informe o código do veículo")),
				JOptionPane.showInputDialog("Informe o tipo de veículo"),
				JOptionPane.showInputDialog("Informe a montaora do veículo"),
				JOptionPane.showInputDialog("Informe o motor do veículo"),
				JOptionPane.showInputDialog("Informe o ano de fabricação do veículo"),
				JOptionPane.showInputDialog("Informe a placa do veículo "),
				JOptionPane.showInputDialog("Quem é o dono do veículo"));

		objCliente.setVeiculo(objVeiculo);

		// int codigo, String tipo, String montadora, String motor, String anoFabricacao, String placa, String dono, int codigo2, String modelo
		Carro objCarro = new Carro(Integer.parseInt(JOptionPane.showInputDialog("Informe o código do carro")), 
				JOptionPane.showInputDialog("Informe o tipo de carro"),
				JOptionPane.showInputDialog("Informe a montaora do Carro"), 
				JOptionPane.showInputDialog("Informe o motor do carro"), 
				JOptionPane.showInputDialog("Informe o ano de fabricação do carro"),
				JOptionPane.showInputDialog("Informe a placa do carro"), 
				JOptionPane.showInputDialog("Quem é o dono do carro"),
				Integer.parseInt(JOptionPane.showInputDialog("Informe o codigo do carro")), 
				JOptionPane.showInputDialog("Informe o modelo do carro"));

		// int codigo, String tipo, String montadora, String motor, String anoFabricacao, String placa, String dono, int codigo2, String modelo
		Moto objMoto = new Moto(Integer.parseInt(JOptionPane.showInputDialog("Informe o código da moto")), 
				JOptionPane.showInputDialog("Informe o tipo da moto"),
				JOptionPane.showInputDialog("Informe a montaora da moto"), 
				JOptionPane.showInputDialog("Informe o motor da moto"), 
				JOptionPane.showInputDialog("Informe o ano de fabricação da moto"),
				JOptionPane.showInputDialog("Informe a placa da moto"), 
				JOptionPane.showInputDialog("Quem é o dono da moto"),
				Integer.parseInt(JOptionPane.showInputDialog("Informe o codigo da moto")), 
				JOptionPane.showInputDialog("Informe o modelo da moto"));
		
		//int codigo, String telefone, String celular, String email, String observacao
		Contato objContato = new Contato(Integer.parseInt(JOptionPane.showInputDialog("Informe o codigo do contato")),
				JOptionPane.showInputDialog("Informe o telefone fixo"),
				JOptionPane.showInputDialog("Informe o celular"),
				JOptionPane.showInputDialog("Informe o e-mail"),
				JOptionPane.showInputDialog("Informe as observações"));
				
		
		//int codigo, String logradouro, int numero, String cep, String estado, String complemento, String observacao
		Endereco objEndereco = new Endereco(Integer.parseInt(JOptionPane.showInputDialog("Informe o codigo do endereço")),
				JOptionPane.showInputDialog("Informe o logradouro"),
				Integer.parseInt(JOptionPane.showInputDialog("Informe o numero")),
				JOptionPane.showInputDialog("Informe o CEP do logradouro"),
				JOptionPane.showInputDialog("Informe o estado"),
				JOptionPane.showInputDialog("Informe o complemento"),
				JOptionPane.showInputDialog("Informe as observações"));
		
		objEndereco.setContato(objContato);
		
		objCliente.setEndereco(objEndereco);
		
		
		//int codigo, double precoPeca, double maoDeObra, double valorHora, double valorTotal
		Orcamento objOrcamento = new Orcamento(Integer.parseInt(JOptionPane.showInputDialog("Informe o codigo do orçamento")),
				Double.parseDouble(JOptionPane.showInputDialog("Informe o preco da peça")),
				Double.parseDouble(JOptionPane.showInputDialog("Informe o valor da mão de obra")),
				Double.parseDouble(JOptionPane.showInputDialog("Informe o valor da hora trabalhada")),
				Double.parseDouble(JOptionPane.showInputDialog("Informe o valor total")));
		
		//int codigo, String descricaoProblema, String diagnostico, String partesAfetadas, String pecasUsadas, String horasTrabalhadas
		Oficina objOficna = new Oficina(Integer.parseInt(JOptionPane.showInputDialog("Informe o codigo da oficina")),
				JOptionPane.showInputDialog("Informe a descrição o problema"),
				JOptionPane.showInputDialog("Informe o diagnostico"),
				JOptionPane.showInputDialog("Informe as partes afetadas"),
				JOptionPane.showInputDialog("Informe as peças ultilizadas"),
				JOptionPane.showInputDialog("Informe as horas trabalhadas"));
				
		objOficna.setOrcamento(objOrcamento);;
		
		//int codigo, int dia, String mes, int ano, String diaDaSemana, String observacao
		Agenda objAgenda = new Agenda(Integer.parseInt(JOptionPane.showInputDialog("Informe o codigo do agendamento")),
				Integer.parseInt(JOptionPane.showInputDialog("Informe o dia do agendamento")),
				JOptionPane.showInputDialog("Informe o mês do agendamento"),
				Integer.parseInt(JOptionPane.showInputDialog("Informe o ano do agendamento")),
				JOptionPane.showInputDialog("Informe o dia da semana do agendamento"),
				JOptionPane.showInputDialog("Informe as observações"));
		
		objAgenda.setOficina(objOficna);
		
		objCliente.setAgenda(objAgenda);		
		
		//int codigo, String tipoPagamento, String desconto, String parcelamento
		Pagamento objPagamento = new Pagamento (Integer.parseInt(JOptionPane.showInputDialog("Informe o codigo do pagamento")),
				JOptionPane.showInputDialog("Informe o tipo de pagamento"),
				JOptionPane.showInputDialog("Informe o desconto"),
				JOptionPane.showInputDialog("Informe o parcelamento"));
		
		objPagamento.setOrcamento(objOrcamento);
		
		objCliente.setPagamento(objPagamento);
		
		
		// SAIDAS
		System.out.println("INFORMAÇÕES PESSOAIS DO CLIENTE" + 
		                   "\nCódigo do cliente: " + objCliente.getCodigo() +
		                   "\nNome do cliente: " + objCliente.getNome() + 
		                   "\nData de nascimento do cliente: " + objCliente.getDataNascimento() + 
		                   "\nProfissão do cliente: " + objCliente.getProfissao() + 
		                   "\nCPF  do cliente: " + objCliente.getCpf() + 
		                   "\n\nINFORMAÇÕES SOBRE ENDEREÇO E CONTATO COM O CLIENTE" +
		                   "\nCódigo do endereço: " + objEndereco.getCodigo() +
		                   "\nLogradouro: " + objEndereco.getLogradouro() + 
		                   "\\nNúmero: " + objEndereco.getNumero() +
		                   "\nCEP: " + objEndereco.getCep() + 
		                   "\nEstado: " + objEndereco.getEstado() + 
		                   "\nComplemento: " + objEndereco.getComplemento() + 
		                   "\nObservações adicionais: " + objEndereco.getObservacao() + 
		                   "\nCogido do contato: " + objEndereco.getContato().getCodigo() + 
		                   "\nTelefone fixo: " + objEndereco.getContato().getTelefone() + 
		                   "\nCelular: " + objEndereco.getContato().getCelular() + 
		                   "\nE-mail: " + objEndereco.getContato().getEmail() + 
		                   "\nObservações adicionais: " + objEndereco.getContato().getObservacao() + 
		                   "\n\nINFORMAÇÕES SOBRE O VEÍCULO" +
		                   "\nCodigo do carro: " + objCarro.getCodigo() + 
		                   "\nTipo do carro: " + objCarro.getTipo() +
		                   "\nMontaora do carro: " + objCarro.getMontadora() +
		                   "\nMotor do carro: " + objCarro.getMotor() + 
		                   "\nAno de fabricação do carro: " + objCarro.getAnoFabricacao() +
		                   "\nPlaca do carro: " + objCarro.getPlaca() + 
		                   "\nDono do carro: " + objCarro.getDono()	+
		                   "\nModelo do carro: " + objCarro.getModelo() +
		                   "\nCodigo da moto: " + objMoto.getCodigo() +
		                   "\nTipo da moto: " + objMoto.getTipo() +
		                   "\nMontaora da moto: " + objMoto.getMontadora() +
		                   "\nMotor da moto: " + objMoto.getMotor() + 
		                   "\nAno de fabricação da moto: " + objMoto.getAnoFabricacao() +
		                   "\nPlaca da moto: " + objMoto.getPlaca() + 
		                   "\nDono da moto: " + objMoto.getDono()	+
		                   "\nModelo da moto: " + objMoto.getModelo() +
		                   "\n\nINFORMAÇÕES SOBRE OFICINA" +
		                   "\nCódigo da ofcina: " + objOficna.getCodigo() + 
		                   "\nDescrição do problema: " + objOficna.getDescricaoProblema() + 
		                   "\nDiagnostico: " + objOficna.getDiagnostico() + 
		                   "\nPartes afetadas: " + objOficna.getPartesAfetadas() + 
		                   "\nPeças ultilizadas: " + objOficna.getPecasUsadas() + 
		                   "\nHoras Trabalhadas: " + objOficna.getHorasTrabalhadas() + 
		                   "\n\nINFORMAÇÕES SOBRE AGENDAMENTO" + 
		                   "\nCódigo do agendamento: " + objAgenda.getCodigo() + 
		                   "\nDia do agendamento: " + objAgenda.getDia() + 
		                   "\nMês do agendamento: " + objAgenda.getMes() + 
		                   "\nAno do agendamento: " + objAgenda.getAno() + 
		                   "\nDia da semana: " + objAgenda.getDiaDaSemana() + 
		                   "\nObservações sobre o agendamento: " + objAgenda.getObservacao() + 
		                   "\n\nINFORMAÇÕES SOBRE ORÇAMENTO" +
		                   "\nCódigo do orçamento: " + objOrcamento.getCodigo() + 
		                   "\nPreço da peça: " + objOrcamento.getPrecoPeca() +
		                   "\nValor da mão de obra: " + objOrcamento.getMaoDeObra() + 
		                   "\nValor a hora trabalhada: " + objOrcamento.getValorHora() + 
		                   "\nValor total: " + objOrcamento.getValorTotal() + 
		                   "\n\nINFORMAÇÕES SOBRE O PAGAMENTO" + 
		                   "\nCódigo o pagamento: " + objPagamento.getCodigo() + 
		                   "\nTipo de pagamento: " + objPagamento.getTipoPagamento() + 
		                   "\nDesconto: " + objPagamento.getDesconto() + 
		                   "\nParcelamento: " + objPagamento.getParcelamento());
	}

}
