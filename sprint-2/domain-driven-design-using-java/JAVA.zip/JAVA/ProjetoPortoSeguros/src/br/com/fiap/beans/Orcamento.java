package br.com.fiap.beans;

public class Orcamento {

	private int codigo;
	private double precoPeca;
	private double maoDeObra;
	private double valorHora;
	private double valorTotal;

	public Orcamento() {
		super();
	}

	public Orcamento(int codigo, double precoPeca, double maoDeObra, double valorHora, double valorTotal) {
		super();
		this.codigo = codigo;
		this.precoPeca = precoPeca;
		this.maoDeObra = maoDeObra;
		this.valorHora = valorHora;
		this.valorTotal = valorTotal;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public double getPrecoPeca() {
		return precoPeca;
	}

	public void setPrecoPeca(double precoPeca) {
		this.precoPeca = precoPeca;
	}

	public double getMaoDeObra() {
		return maoDeObra;
	}

	public void setMaoDeObra(double maoDeObra) {
		this.maoDeObra = maoDeObra;
	}

	public double getValorHora() {
		return valorHora;
	}

	public void setValorHora(double valorHora) {
		this.valorHora = valorHora;
	}

	public double getValorTotal() {
		return valorTotal;
	}

	public void setValorTotal(double valorTotal) {
		this.valorTotal = valorTotal;
	}

}
