# 
# Endereço de hospedagem na internet https://pcar.tech/
#
# TURMAS 1TDSPV-1TDSPZ-2024
#
# challenge sprint 2
#
# GRUPO IT INOVATION
#
# CHALLENGE FRONT-END - 2024
#
# repositórios dos alunos
#
# Carlos Eduardo
# https://github.com/cadupacheco
# RM 557323
#
# Gustavo Gomes
# https://github.com/gugomesx10
# RM 55599
#
# Paulo André Carminati
# https://github.com/carmipa
# RM 557881
