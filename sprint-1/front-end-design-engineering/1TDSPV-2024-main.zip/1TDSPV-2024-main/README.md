# 1TDSPV-2024
#
# GRUPO IT INOVATION
#
# CHALLENGE FRONT-END - 2024
#
# CONTA DO FIGMA:
# LOGIN: fofocaslulu93@gmail.com
# SENHA: Fiap12345
#
# repositórios dos alunos
#
# Carlos Eduardo
# https://github.com/cadupacheco
# RM 557323
#
# Gustavo Gomes
# https://github.com/gugomesx10
# RM 55599
# #
# Paulo André Carminati
# https://github.com/carmipa
# RM 557881



